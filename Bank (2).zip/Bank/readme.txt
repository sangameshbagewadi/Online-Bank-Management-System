Free Download Source Code "Bank Management System"

FIRST Download

1.XAMPP

2."TEXT EDITOR" NOTEPAD++ OR SUBLIME TEXT 3 / ETC.

3"bank"

4. Download the zip file/ download winrar

5. Extract the file and copy "bank" folder

6.Paste inside root directory/ where you install xammp local disk C: drive D: drive E: paste: (for xampp/htdocs, 

7. Open PHPMyAdmin (http://localhost/phpmyadmin)

8. Create a database with name mybank

6. Import mybank.sql file(given inside the zip package in SQL file folder)

7.Run the script http://localhost/bank

**LOGIN DETAILS** 

Manager
Username:   manager@manager.com
Passwored:  manager

Cashier
Username :cashier@cashier.com
Password :cashier

User
Username: some@gmail.com
Password: some