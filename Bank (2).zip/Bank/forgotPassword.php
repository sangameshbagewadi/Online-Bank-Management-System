<body style="background: url(images/ca.jpg);background-size: 90%">                  

<section id="contact" class="contact section-bg">
      <div class="container aos-init aos-animate" data-aos="fade-up">

        <div class="section-title">
          <h2>Contact</h2>
          <p>For Any query related to bank or account please contact us. We are trying to solve your all problems</p>
       
        </div>


        <div class="row">
          <div class="col-lg-6">
            <div class="info-box mb-4">
              <i class="bx bx-map"></i>
              

          <div class="col-lg-3 col-md-6">
            <div class="info-box  mb-4">
              <i class="bx bx-envelope"></i>
              <h3>Email Us</h3>
              <p>manager@manager.com</p>
            </div>
          </div>

          

        </div>
        
        <div class="row">

          <div class="col-lg-6">
            <form action="" method="POST">
              <div class="row">
                <div class="col-md-6 form-group">
                  <input type="text" name="name" class="form-control" id="name" placeholder="Your Name" required="">
                </div>
                <div class="col-md-6 form-group mt-3 mt-md-0">
                  <input type="email" class="form-control" name="email" id="email" placeholder="Your Email" required="">
                </div>
              </div>
              <div class="form-group mt-3">
                <input type="text" class="form-control" name="subject" id="subject" placeholder="Subject" required="">
              </div>
              <div class="form-group mt-3">
                <textarea class="form-control" id="message" name="message" rows="5" placeholder="Message" required=""></textarea>
              <div hidden="" id="status"></div>
              <div hidden="" id="error-message" class="alert alert-danger mt-3"></div>
              <div hidden="" id="success-message" class="alert alert-success mt-3"></div>
              <div class="text-center"><button class="btn-custo mt-3" id="submit" href="login.php" name="submit">Send Message <i class="bx bxs-send"></i></button>
			  </div>
            
          </div>
              <div hidden="" id="status"></div>
              <div hidden="" id="error-message" class="alert alert-danger mt-3"></div>
              <div hidden="" id="success-message" class="alert alert-success mt-3"></div>
            </form> 
          </div>

        </div>
       