<!DOCTYPE html>
<html>
<head>
	<title>Banking</title>
	<?php require 'assets/autoloader.php'; ?>
	<?php require 'assets/function.php'; ?>
	<?php
    
    define('bankname', 'Global bank');
	session_start();
	
           $con=new mysqli("localhost","root","","mybank2");
		$error = "";
		if (isset($_POST['userLogin']))
		{
			$error = "";
  			$user = $_POST['email'];
		    $pass = $_POST['password'];
		   
		    $result = $con->query("select * from userAccounts where email='$user' AND password='$pass'");
		    if($result->num_rows>0)
		    { 
		      $data = $result->fetch_assoc();
		      $_SESSION['userId']=$data['id'];
		      $_SESSION['user'] = $data;
		      header('location:index.php');
		     }
		    else
		    {
		      $error = "<div class='alert alert-warning text-center rounded-0'>Username or password wrong try again!</div>";
		    }
		}
		if (isset($_POST['cashierLogin']))
		{
			$error = "";
  			$user = $_POST['email'];
		    $pass = $_POST['password'];
		   
		    $result = $con->query("select * from login where email='$user' AND password='$pass'");
		    if($result->num_rows>0)
		    { 
		      $data = $result->fetch_assoc();
		      $_SESSION['cashId']=$data['id'];
		      //$_SESSION['user'] = $data;
		      header('location:cindex.php');
		     }
		    else
		    {
		      $error = "<div class='alert alert-warning text-center rounded-0'>Username or password wrong try again!</div>";
		    }
		}
		if (isset($_POST['managerLogin']))
		{
			$error = "";
  			$user = $_POST['email'];
		    $pass = $_POST['password'];
		   
		    $result = $con->query("select * from login where email='$user' AND password='$pass' AND type='manager'");
		    if($result->num_rows>0)
		    { 
		      $data = $result->fetch_assoc();
		      $_SESSION['managerId']=$data['id'];
		      //$_SESSION['user'] = $data;
		      header('location:mindex.php');
		     }
		    else
		    {
		      $error = "<div class='alert alert-warning text-center rounded-0'>Username or password wrong try again!</div>";
		    }
		}

	 ?>
</head>
<body style="background: url(images/blue.png);background-size: 95%">
<a class="navbar-brand" href="#">
   <h1> <img src="images/logo.png" style="object-fit:cover;object-position:center center" width="150" height="120"  class="alert alert-dark bg-gradient-dark rounded-0"><?php echo bankname;?></h1>
    </a>

      <h2>  <a class="w-15 float-right shadowBlack" style="margin-right: 10px" href="stafflogin.php">StaffLogin</a>
 </h2>


<br>
<?php echo $error ?>
<br>
<div class="w-25 float-left shadowBlack" style="margin-right: 400px">
	<br><h4 ></h4>
  <div >
    <div>
      <h5 >
        <a style="text-decoration: none;" data-toggle="collapse" href="#collapseOne" aria-expanded="true" aria-controls="collapseOne">
         <button class="btn btn-outline-primary btn-block">User Login</button>
        </a>
      </h5>
    </div>

    <div id="collapseOne" class="collapse" role="tabpanel" aria-labelledby="headingOne" data-parent="#accordion">
      <div class="card-body">
       <form method="POST">
       	<input type="email" value="" name="email" class="form-control" required placeholder="Enter Your Email">
       	<input type="password" name="password" value="" class="form-control" required placeholder="Enter Your Password">
       	<button type="submit" class="btn btn-primary btn-block btn-sm my-1" name="userLogin">Enter </button><br>
        <a href="forgotPassword.php" class="forgot-password-link">Forgot password?</a>
       </form>
      </div>
    </div>
  </div>
  </div>
<div>

<marquee width="100%" direction="left" height="200px"  font-size="500px">   </marquee>
<br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br>
<nav id="navbar" class="navbar">
        
       <h6> <a class="nav-link scrollto active" href="login.php">Services</a></h6>
        
    </nav> 

<div id="carouselExampleIndicators" class="carousel slide my-2 rounded-1 shadowBlack" data-ride="carousel" >
          <div class="carousel-inner">
          <div class="carousel-item">
            <img class="d-block w-100" src="images/DP.png" alt="First slide" style="max-height: 600px">
          </div>
          <div class="carousel-item active">
            <img class="d-block w-100" src="images/loan.png" alt="Second slide" style="max-height: 600px">
          </div>
          <div class="carousel-item">
            <img class="d-block w-100" src="images/3.jpg" alt="Third slide" style="max-height: 600px">
          </div>
		  <div class="carousel-item">
            <img class="d-block w-100" src="images/fest.png" alt="fourth slide" style="max-height: 600px">
          </div>
		  
		  <div class="carousel-item">
            <img class="d-block w-100" src="images/5.jpg" alt="sixth slide" style="max-height: 600px">
          </div>

        </div>
        <a class="carousel-control-prev" href="#carouselExampleIndicators" role="button" data-slide="prev">
          <span class="carousel-control-prev-icon" aria-hidden="true"></span>
          <span class="sr-only">Previous</span>
        </a>
        <a class="carousel-control-next" href="#carouselExampleIndicators" role="button" data-slide="next">
          <span class="carousel-control-next-icon" aria-hidden="true"></span>
          <span class="sr-only">Next</span>
        </a>
      </div>

</body>
<br>

<section id="contact" class="contact section-bg">
      <div class="container aos-init aos-animate" data-aos="fade-up">

        <div class="section-title">
          <h2>Contact</h2>
          <p>For Any query related to bank or account please contact us.<br><br><br> We are trying to solve your all problems</p>
        </div>

        <div class="row">
          <div class="col-lg-6">
            <div class="info-box mb-4">
              <i class="bx bx-map"></i>
              <h3>Our Address</h3>
              <p>Sankeshwar, India 591313</p>
            </div>
          </div>

          <div class="col-lg-3 col-md-6">
            <div class="info-box  mb-4">
              <i class="bx bx-envelope"></i>
              <h3>Email Us</h3>
              <p>manager@manager.com</p>
            </div>
          </div>

          <div class="col-lg-3 col-md-6">
            <div class="info-box  mb-4">
              <i class="bx bx-phone-call"></i>
              <h3>Call Us</h3>
              <p>+91 9448352518</p>
            </div>
          </div>

        </div>

        <div class="row">

          <div class="col-lg-6">
            <form action="" method="POST">
              <div class="row">
                <div class="col-md-6 form-group">
                  <input type="text" name="name" class="form-control" id="name" placeholder="Your Name" required="">
                </div>
                <div class="col-md-6 form-group mt-3 mt-md-0">
                  <input type="email" class="form-control" name="email" id="email" placeholder="Your Email" required="">
                </div>
              </div>
              <div class="form-group mt-3">
                <input type="text" class="form-control" name="subject" id="subject" placeholder="Subject" required="">
              </div>
              <div class="form-group mt-2">
                <textarea class="form-control" id="message" name="message" rows="2" placeholder="Message" required=""></textarea>
              </div>
              <div hidden="" id="status"></div>
              <div hidden="" id="error-message" class="alert alert-danger mt-3"></div>
              <div hidden="" id="success-message" class="alert alert-success mt-3"></div>
              <div class="text-center"><button class="btn-custo mt-1" id="submit" href="mfeedback.php" name="submit">Send Message <i class="bx bxs-send"></i></button>
			  </div>
            </form>
          </div>

        </div>
  
      </div>
    </section>
</html>